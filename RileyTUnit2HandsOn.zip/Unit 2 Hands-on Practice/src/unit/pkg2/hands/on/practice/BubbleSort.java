// From the textbook slides used to see if Bubblesort would work
package unit.pkg2.hands.on.practice;

public class BubbleSort {

      /** Bubble sort method */
  public static void bubbleSort() {
              int[] arr = new int[50000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 50000;
        }
        
           long startTime = System.currentTimeMillis();
        boolean needNextPass = true;

    for (int k = 1; k < arr.length && needNextPass; k++) {
      // Array may be sorted and next pass not needed
      needNextPass = false;
      for (int i = 0; i < arr.length - k; i++) {
        if (arr[i] > arr[i + 1]) {
          // Swap list[i] with list[i + 1]
          int temp = arr[i];
          arr[i] = arr[i + 1];
          arr[i + 1] = temp;

          needNextPass = true; // Next pass still needed
        }
      }
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
  } // end of method 50000
  
    public static void bubbleSort100000() {
              int[] arr = new int[100000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 100000;
        }
        
           long startTime = System.currentTimeMillis();
        boolean needNextPass = true;

    for (int k = 1; k < arr.length && needNextPass; k++) {
      // Array may be sorted and next pass not needed
      needNextPass = false;
      for (int i = 0; i < arr.length - k; i++) {
        if (arr[i] > arr[i + 1]) {
          // Swap list[i] with list[i + 1]
          int temp = arr[i];
          arr[i] = arr[i + 1];
          arr[i + 1] = temp;

          needNextPass = true; // Next pass still needed
        }
      }
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
  } // end of method 100000
    
      public static void bubbleSort150000() {
              int[] arr = new int[150000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 150000;
        }
        
           long startTime = System.currentTimeMillis();
        boolean needNextPass = true;

    for (int k = 1; k < arr.length && needNextPass; k++) {
      // Array may be sorted and next pass not needed
      needNextPass = false;
      for (int i = 0; i < arr.length - k; i++) {
        if (arr[i] > arr[i + 1]) {
          // Swap list[i] with list[i + 1]
          int temp = arr[i];
          arr[i] = arr[i + 1];
          arr[i + 1] = temp;

          needNextPass = true; // Next pass still needed
        }
      }
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
  } // end of method 150000
      
        public static void bubbleSort200000() {
              int[] arr = new int[200000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 200000;
        }
        
           long startTime = System.currentTimeMillis();
        boolean needNextPass = true;

    for (int k = 1; k < arr.length && needNextPass; k++) {
      // Array may be sorted and next pass not needed
      needNextPass = false;
      for (int i = 0; i < arr.length - k; i++) {
        if (arr[i] > arr[i + 1]) {
          // Swap list[i] with list[i + 1]
          int temp = arr[i];
          arr[i] = arr[i + 1];
          arr[i + 1] = temp;

          needNextPass = true; // Next pass still needed
        }
      }
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
  } // end of method 200000
        
    public static void bubbleSort250000() {
              int[] arr = new int[250000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 250000;
        }
        
           long startTime = System.currentTimeMillis();
        boolean needNextPass = true;

    for (int k = 1; k < arr.length && needNextPass; k++) {
      // Array may be sorted and next pass not needed
      needNextPass = false;
      for (int i = 0; i < arr.length - k; i++) {
        if (arr[i] > arr[i + 1]) {
          // Swap list[i] with list[i + 1]
          int temp = arr[i];
          arr[i] = arr[i + 1];
          arr[i + 1] = temp;

          needNextPass = true; // Next pass still needed
        }
      }
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
  } // end of method 250000
    
    public static void bubbleSort300000() {
              int[] arr = new int[300000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 300000;
        }
        
           long startTime = System.currentTimeMillis();
        boolean needNextPass = true;

    for (int k = 1; k < arr.length && needNextPass; k++) {
      // Array may be sorted and next pass not needed
      needNextPass = false;
      for (int i = 0; i < arr.length - k; i++) {
        if (arr[i] > arr[i + 1]) {
          // Swap list[i] with list[i + 1]
          int temp = arr[i];
          arr[i] = arr[i + 1];
          arr[i + 1] = temp;

          needNextPass = true; // Next pass still needed
        }
      }
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
  } // end of method 300000
}// end of class

