//http://www.sanfoundry.com/java-program-implement-heap-sort/
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unit.pkg2.hands.on.practice;

import java.util.Scanner;

/**
 *
 * @author tr0100936
 */
public class HeapSort {
        /*

     * Java Program to Implement Heap Sort

     */

     

   //import java.util.Scanner;

     

    /* Class HeapSort */

//    public class HeapSort 

//    {    

        private static int N;

        /* Sort Function */

        public static void sort()

        {       
                    int[] arr = new int[10];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 10;
        }
        
            long startTime = System.currentTimeMillis();
            heapify(arr);        

            for (int i = N; i > 0; i--)

            {

                swap(arr,0, i);

                N = N-1;

                maxheap(arr, 0);
            long endTime = System.currentTimeMillis();
     
            System.out.print("   " + (endTime - startTime) + "     ");
            }

        } // end of method 50000
        
                public static void sort100000()

        {       
                    int[] arr = new int[100000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 100000;
        }
        
            long startTime = System.currentTimeMillis();
            heapify(arr);        

            for (int i = N; i > 0; i--)

            {

                swap(arr,0, i);

                N = N-1;

                maxheap(arr, 0);
            long endTime = System.currentTimeMillis();
     
            System.out.print("   " + (endTime - startTime) + "     ");
            }

        } // end of method 100000
                
                       public static void sort150000()

        {       
                    int[] arr = new int[150000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 150000;
        }
        
            long startTime = System.currentTimeMillis();
            heapify(arr);        

            for (int i = N; i > 0; i--)

            {

                swap(arr,0, i);

                N = N-1;

                maxheap(arr, 0);
            long endTime = System.currentTimeMillis();
     
            System.out.print("   " + (endTime - startTime) + "     ");
            }

        } // end of method 150000
                
                       public static void sort200000()

        {       
                    int[] arr = new int[200000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 200000;
        }
        
            long startTime = System.currentTimeMillis();
            heapify(arr);        

            for (int i = N; i > 0; i--)

            {

                swap(arr,0, i);

                N = N-1;

                maxheap(arr, 0);
            long endTime = System.currentTimeMillis();
     
            System.out.print("   " + (endTime - startTime) + "     ");
            }

        } // end of method 200000
                       
                       public static void sort250000()

        {       
                    int[] arr = new int[250000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 250000;
        }
        
            long startTime = System.currentTimeMillis();
            heapify(arr);        

            for (int i = N; i > 0; i--)

            {

                swap(arr,0, i);

                N = N-1;

                maxheap(arr, 0);
            long endTime = System.currentTimeMillis();
     
            System.out.print("   " + (endTime - startTime) + "     ");
            }

        } // end of method 250000
                       
                       public static void sort300000()

        {       
                    int[] arr = new int[300000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 300000;
        }
        
            long startTime = System.currentTimeMillis();
            heapify(arr);        

            for (int i = N; i > 0; i--)

            {

                swap(arr,0, i);

                N = N-1;

                maxheap(arr, 0);
            long endTime = System.currentTimeMillis();
     
            System.out.print("   " + (endTime - startTime) + "     ");
            }

        } // end of method 300000
        
        

        /* Function to build a heap */   

        public static void heapify(int arr[])

        {

            N = arr.length-1;

            for (int i = N/2; i >= 0; i--)

                maxheap(arr, i);        

        }

        /* Function to swap largest element in heap */        

        public static void maxheap(int arr[], int i)

        { 
 
            int left = 2*i ;

            int right = 2*i + 1;

            int max = i;

            if (left <= N && arr[left] > arr[i])

                max = left;

            if (right <= N && arr[right] > arr[max])        

                max = right;

     

            if (max != i)

            {

                swap(arr, i, max);

                maxheap(arr, max);

            }
 
        }    

        /* Function to swap two numbers in an array */

        public static void swap(int arr[], int i, int j)

        {
       
            int tmp = arr[i];

            arr[i] = arr[j];

            arr[j] = tmp; 

        }    

        /* Main method */

     //   public static void main(String[] args) 

    //    {

    //        Scanner scan = new Scanner( System.in );        

     //       System.out.println("Heap Sort Test\n");

     //       int n, i;    

            /* Accept number of elements */

     //       System.out.println("Enter number of integer elements");

     //       n = scan.nextInt();    

            /* Make array of n elements */

    //        int arr[] = new int[ n ];

            /* Accept elements */

     //       System.out.println("\nEnter "+ n +" integer elements");

    //        for (i = 0; i < n; i++)

    //            arr[i] = scan.nextInt();

            /* Call method sort */

    //        sort(arr);

            /* Print sorted Array */

    //        System.out.println("\nElements after sorting ");        

    //        for (i = 0; i < n; i++)

    //            System.out.print(arr[i]+" ");            

    //        System.out.println();            

    //    }    

    }

