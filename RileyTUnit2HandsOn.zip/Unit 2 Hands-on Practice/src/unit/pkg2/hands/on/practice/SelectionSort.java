// http://web.cs.iastate.edu/~smkautz/cs227f12/examples/week11/SelectionSortExamples.java - Selection sort
package unit.pkg2.hands.on.practice;

public class SelectionSort {
    public static void selectionSort()//(int[] arr)
  { 
              int[] arr = new int[50000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * 50000);
        }

      
    long startTime = System.currentTimeMillis();
    
    for (int i = 0; i < arr.length - 1; ++i)
    {
      int minIndex = i;
      for (int j = i + 1; j < arr.length; ++j)
      {
        if (arr[j] < arr[minIndex])
        {
          minIndex = j;
        }
      }
      int temp = arr[i];
      arr[i] = arr[minIndex];
      arr[minIndex] = temp;
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");

} // end of method selectionSort  
    
     public static void selectionSort100000()//(int[] arr)
  { 
              int[] arr = new int[100000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * 100000);
        }

      
    long startTime = System.currentTimeMillis();
    
    for (int i = 0; i < arr.length - 1; ++i)
    {
      int minIndex = i;
      for (int j = i + 1; j < arr.length; ++j)
      {
        if (arr[j] < arr[minIndex])
        {
          minIndex = j;
        }
      }
      int temp = arr[i];
      arr[i] = arr[minIndex];
      arr[minIndex] = temp;
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");

}      
     
          public static void selectionSort150000()//(int[] arr)
  { 
              int[] arr = new int[150000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * 150000);
        }

      
    long startTime = System.currentTimeMillis();
    
    for (int i = 0; i < arr.length - 1; ++i)
    {
      int minIndex = i;
      for (int j = i + 1; j < arr.length; ++j)
      {
        if (arr[j] < arr[minIndex])
        {
          minIndex = j;
        }
      }
      int temp = arr[i];
      arr[i] = arr[minIndex];
      arr[minIndex] = temp;
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");

} // end of method selectionSort150000
          
     public static void selectionSort200000()//(int[] arr)
  { 
              int[] arr = new int[200000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * 200000);
        }

      
    long startTime = System.currentTimeMillis();
    
    for (int i = 0; i < arr.length - 1; ++i)
    {
      int minIndex = i;
      for (int j = i + 1; j < arr.length; ++j)
      {
        if (arr[j] < arr[minIndex])
        {
          minIndex = j;
        }
      }
      int temp = arr[i];
      arr[i] = arr[minIndex];
      arr[minIndex] = temp;
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");

} // end of method selection200000
     
     public static void selectionSort250000()//(int[] arr)
  { 
              int[] arr = new int[250000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * 250000);
        }

      
    long startTime = System.currentTimeMillis();
    
    for (int i = 0; i < arr.length - 1; ++i)
    {
      int minIndex = i;
      for (int j = i + 1; j < arr.length; ++j)
      {
        if (arr[j] < arr[minIndex])
        {
          minIndex = j;
        }
      }
      int temp = arr[i];
      arr[i] = arr[minIndex];
      arr[minIndex] = temp;
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");

} // end of method selectSort250000 
     
     public static void selectionSort300000()//(int[] arr)
  { 
              int[] arr = new int[300000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * 300000);
        }

      
    long startTime = System.currentTimeMillis();
    
    for (int i = 0; i < arr.length - 1; ++i)
    {
      int minIndex = i;
      for (int j = i + 1; j < arr.length; ++j)
      {
        if (arr[j] < arr[minIndex])
        {
          minIndex = j;
        }
      }
      int temp = arr[i];
      arr[i] = arr[minIndex];
      arr[minIndex] = temp;
    }
         long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");

} // end of selectionSort300000
} // end of class
