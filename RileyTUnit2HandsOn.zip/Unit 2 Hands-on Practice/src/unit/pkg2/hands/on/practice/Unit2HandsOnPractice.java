package unit.pkg2.hands.on.practice;

import java.util.Scanner;

public class Unit2HandsOnPractice {

    public static void main(String[] args) {
             Scanner scan = new Scanner( System.in );
        System.out.println("Radix Sort Test\n");
        

         // Create an object
        SelectionSort bike0 = new SelectionSort();
        RadixSort bike1 = new RadixSort();
        BubbleSort bike2 = new BubbleSort();
        MergeSort bike3  = new MergeSort();
        QuickSort bike4 = new QuickSort();     
        HeapSort bike5 = new HeapSort();

                
        /** Accept number of elements **/
        //System.out.println("Enter number of integer elements");
        //n = scan.nextInt();
        /** Create integer array on n elements **/
        int[] arr = new int[10];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 10;
        }
        
        
        /** Accept elements **/
        //System.out.println("\nEnter "+ n +" integer elements");
        //for (i = 0; i < n; i++)
         //   arr[i] = scan.nextInt();
        /** Call method sort **/
       // bike0.selectionSort(arr);
       // bike1.sort(arr);
       // bike2.bubbleSort(arr);
       // bike3.mergeSort(arr);
       // bike4.quickSort(arr);
       // bike5.sort(arr);
        // sort(arr);
        /** Print sorted Array **/
        System.out.println("\nElements after sorting ");
        int n;
        for (int i = 0; i < arr.length; i++)
           System.out.print(arr[i]+" ");
        System.out.println(); 
        
        
        
   //     public class SelectionSortExamples
      {
  //	public static void main(String[] args)
//	{
//		Integer[] a = {2, 6, 3, 5, 1};
//		MergeSort(a);
//		System.out.println(Arrays.toString(a));
//	}
        
        // prints the table
        System.out.println("arraysize   Selection sort | Radix sort | Bubble sort | Merge sort | Quick sort | Heap sort");
        System.out.print("50000");
        bike0.selectionSort();
        bike1.sort();
        bike2.bubbleSort();
    //    bike3.mergeSort();
    //    bike4.quickSort();
        bike5.sort();
        System.out.print("100000");
        bike0.selectionSort100000();
        bike1.sort100000();
        bike2.bubbleSort100000();
    //    bike3.mergeSort100000();
    //    bike4.quickSort100000();
        bike5.sort100000();
        System.out.print("150000");
        bike0.selectionSort150000();
        bike1.sort150000();
        bike2.bubbleSort150000();
    //    bike3.mergeSort150000();
    //    bike4.quickSort150000();
        bike5.sort150000();
        System.out.print("200000");
        bike0.selectionSort200000();
        bike1.sort200000();
        bike2.bubbleSort200000();
    //    bike3.mergeSort200000();
    //    bike4.quickSort200000();
        bike5.sort200000();
        System.out.print("250000");
        bike0.selectionSort250000();
        bike1.sort250000();
        bike2.bubbleSort250000();
    //    bike3.mergeSort250000();
     //   bike4.quickSort250000();
        bike5.sort250000();
        System.out.print("300000");
        bike0.selectionSort300000();
        bike1.sort300000();
        bike2.bubbleSort300000();
    //    bike3.mergeSort300000();
    //    bike4.quickSort300000();
        bike5.sort300000();
  
        
        
      }
   }
}