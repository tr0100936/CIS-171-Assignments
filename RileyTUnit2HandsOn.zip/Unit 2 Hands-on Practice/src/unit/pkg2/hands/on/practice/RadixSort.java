// http://www.sanfoundry.com/java-program-implement-radix-sort/
package unit.pkg2.hands.on.practice;

public class RadixSort {

   public static void sort()
   {
               int[] a = new int[50000];
        for (int i = 0; i < a.length; i++) {
            a[i] = (int)Math.random() * 50000;
        }
        
            long startTime = System.currentTimeMillis();
      int i, m = a[0], exp = 1, n = a.length;
      int[] b = new int[10];
      for (i = 1; i < n; i++)
         if (a[i] > m)
            m = a[i];
      while (m / exp > 0)
      {
         int[] bucket = new int[10];

         for (i = 0; i < n; i++)
            bucket[(a[i] / exp) % 10]++;
         for (i = 1; i < 10; i++)
            bucket[i] += bucket[i - 1];
         for (i = n - 1; i >= 0; i--)
            b[--bucket[(a[i] / exp) % 10]] = a[i];
         for (i = 0; i < n; i++)
            a[i] = b[i];
         exp *= 10;
      }
           long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
} // end of method50000
   
   public static void sort100000()
   {
               int[] a = new int[100000];
        for (int i = 0; i < a.length; i++) {
            a[i] = (int)Math.random() * 100000;
        }
        
            long startTime = System.currentTimeMillis();
      int i, m = a[0], exp = 1, n = a.length;
      int[] b = new int[10];
      for (i = 1; i < n; i++)
         if (a[i] > m)
            m = a[i];
      while (m / exp > 0)
      {
         int[] bucket = new int[10];

         for (i = 0; i < n; i++)
            bucket[(a[i] / exp) % 10]++;
         for (i = 1; i < 10; i++)
            bucket[i] += bucket[i - 1];
         for (i = n - 1; i >= 0; i--)
            b[--bucket[(a[i] / exp) % 10]] = a[i];
         for (i = 0; i < n; i++)
            a[i] = b[i];
         exp *= 10;
      }
           long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
} // end of method100000
 
   public static void sort150000()
   {
               int[] a = new int[150000];
        for (int i = 0; i < a.length; i++) {
            a[i] = (int)Math.random() * 150000;
        }
        
            long startTime = System.currentTimeMillis();
      int i, m = a[0], exp = 1, n = a.length;
      int[] b = new int[10];
      for (i = 1; i < n; i++)
         if (a[i] > m)
            m = a[i];
      while (m / exp > 0)
      {
         int[] bucket = new int[10];

         for (i = 0; i < n; i++)
            bucket[(a[i] / exp) % 10]++;
         for (i = 1; i < 10; i++)
            bucket[i] += bucket[i - 1];
         for (i = n - 1; i >= 0; i--)
            b[--bucket[(a[i] / exp) % 10]] = a[i];
         for (i = 0; i < n; i++)
            a[i] = b[i];
         exp *= 10;
      }
           long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
} // end of method150000  
   
   public static void sort200000()
   {
               int[] a = new int[200000];
        for (int i = 0; i < a.length; i++) {
            a[i] = (int)Math.random() * 200000;
        }
        
            long startTime = System.currentTimeMillis();
      int i, m = a[0], exp = 1, n = a.length;
      int[] b = new int[10];
      for (i = 1; i < n; i++)
         if (a[i] > m)
            m = a[i];
      while (m / exp > 0)
      {
         int[] bucket = new int[10];

         for (i = 0; i < n; i++)
            bucket[(a[i] / exp) % 10]++;
         for (i = 1; i < 10; i++)
            bucket[i] += bucket[i - 1];
         for (i = n - 1; i >= 0; i--)
            b[--bucket[(a[i] / exp) % 10]] = a[i];
         for (i = 0; i < n; i++)
            a[i] = b[i];
         exp *= 10;
      }
           long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
} // end of method200000
   
   public static void sort250000()
   {
               int[] a = new int[250000];
        for (int i = 0; i < a.length; i++) {
            a[i] = (int)Math.random() * 250000;
        }
        
            long startTime = System.currentTimeMillis();
      int i, m = a[0], exp = 1, n = a.length;
      int[] b = new int[10];
      for (i = 1; i < n; i++)
         if (a[i] > m)
            m = a[i];
      while (m / exp > 0)
      {
         int[] bucket = new int[10];

         for (i = 0; i < n; i++)
            bucket[(a[i] / exp) % 10]++;
         for (i = 1; i < 10; i++)
            bucket[i] += bucket[i - 1];
         for (i = n - 1; i >= 0; i--)
            b[--bucket[(a[i] / exp) % 10]] = a[i];
         for (i = 0; i < n; i++)
            a[i] = b[i];
         exp *= 10;
      }
           long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
} // end of method250000
   
   public static void sort300000()
   {
               int[] a = new int[300000];
        for (int i = 0; i < a.length; i++) {
            a[i] = (int)Math.random() * 300000;
        }
        
            long startTime = System.currentTimeMillis();
      int i, m = a[0], exp = 1, n = a.length;
      int[] b = new int[10];
      for (i = 1; i < n; i++)
         if (a[i] > m)
            m = a[i];
      while (m / exp > 0)
      {
         int[] bucket = new int[10];

         for (i = 0; i < n; i++)
            bucket[(a[i] / exp) % 10]++;
         for (i = 1; i < 10; i++)
            bucket[i] += bucket[i - 1];
         for (i = n - 1; i >= 0; i--)
            b[--bucket[(a[i] / exp) % 10]] = a[i];
         for (i = 0; i < n; i++)
            a[i] = b[i];
         exp *= 10;
      }
           long endTime = System.currentTimeMillis();
     
      System.out.print("   " + (endTime - startTime) + "     ");
} // end of method300000

} // end of class

