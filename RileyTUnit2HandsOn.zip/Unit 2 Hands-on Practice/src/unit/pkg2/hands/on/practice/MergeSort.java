// www.cs.cmu.edu/~adamchik/15-121/lectures/Sorting%20A... 
package unit.pkg2.hands.on.practice;

public class MergeSort {

	public static void mergeSort(Comparable [ ] a)
	{
		Comparable[] tmp = new Comparable[a.length];
		mergeSort(a, tmp,  0,  a.length - 1);
	}


	private static void mergeSort(Comparable [ ] a, Comparable [ ] tmp, int left, int right)
	{
                    int[] arr = new int[50000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 50000;
        }
        
                 long startTime = System.currentTimeMillis();
		if( left < right )
		{
			int center = (left + right) / 2;
			mergeSort(a, tmp, left, center);
			mergeSort(a, tmp, center + 1, right);
			merge(a, tmp, left, center + 1, right);
		}
                      long endTime = System.currentTimeMillis();
                      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of method 50000
        
        	private static void mergeSort100000(Comparable [ ] a, Comparable [ ] tmp, int left, int right)
	{
                    int[] arr = new int[100000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 100000;
        }
        
                 long startTime = System.currentTimeMillis();
		if( left < right )
		{
			int center = (left + right) / 2;
			mergeSort(a, tmp, left, center);
			mergeSort(a, tmp, center + 1, right);
			merge(a, tmp, left, center + 1, right);
		}
                      long endTime = System.currentTimeMillis();
                      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of method 100000
                
       	private static void mergeSort150000(Comparable [ ] a, Comparable [ ] tmp, int left, int right)
	{
                    int[] arr = new int[150000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 150000;
        }
        
                 long startTime = System.currentTimeMillis();
		if( left < right )
		{
			int center = (left + right) / 2;
			mergeSort(a, tmp, left, center);
			mergeSort(a, tmp, center + 1, right);
			merge(a, tmp, left, center + 1, right);
		}
                      long endTime = System.currentTimeMillis();
                      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of method 150000 
        
        	private static void mergeSort200000(Comparable [ ] a, Comparable [ ] tmp, int left, int right)
	{
                    int[] arr = new int[200000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 200000;
        }
        
                 long startTime = System.currentTimeMillis();
		if( left < right )
		{
			int center = (left + right) / 2;
			mergeSort(a, tmp, left, center);
			mergeSort(a, tmp, center + 1, right);
			merge(a, tmp, left, center + 1, right);
		}
                      long endTime = System.currentTimeMillis();
                      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of method 200000
                
        	private static void mergeSort250000(Comparable [ ] a, Comparable [ ] tmp, int left, int right)
	{
                    int[] arr = new int[250000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 250000;
        }
        
                 long startTime = System.currentTimeMillis();
		if( left < right )
		{
			int center = (left + right) / 2;
			mergeSort(a, tmp, left, center);
			mergeSort(a, tmp, center + 1, right);
			merge(a, tmp, left, center + 1, right);
		}
                      long endTime = System.currentTimeMillis();
                      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of method 250000
                
        	private static void mergeSort300000(Comparable [ ] a, Comparable [ ] tmp, int left, int right)
	{
                    int[] arr = new int[300000];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 300000;
        }
        
                 long startTime = System.currentTimeMillis();
		if( left < right )
		{
			int center = (left + right) / 2;
			mergeSort(a, tmp, left, center);
			mergeSort(a, tmp, center + 1, right);
			merge(a, tmp, left, center + 1, right);
		}
                      long endTime = System.currentTimeMillis();
                      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of method 300000


    private static void merge(Comparable[ ] a, Comparable[ ] tmp, int left, int right, int rightEnd )
    {
        int leftEnd = right - 1;
        int k = left;
        int num = rightEnd - left + 1;

        while(left <= leftEnd && right <= rightEnd)
            if(a[left].compareTo(a[right]) <= 0)
                tmp[k++] = a[left++];
            else
                tmp[k++] = a[right++];

        while(left <= leftEnd)    // Copy rest of first half
            tmp[k++] = a[left++];

        while(right <= rightEnd)  // Copy rest of right half
            tmp[k++] = a[right++];

        // Copy tmp back
        for(int i = 0; i < num; i++, rightEnd--)
            a[rightEnd] = tmp[rightEnd];
        
     

    } // end of merge method
 } // end of class

