//http://www.programcreek.com/2012/11/quicksort-array-in-java/
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unit.pkg2.hands.on.practice;

/**
 *
 * @author tr0100936
 */
public class QuickSort {
// public static void main(String[] args) {
//		int[] x = { 9, 2, 4, 7, 3, 7, 10 };
//		System.out.println(Arrays.toString(x));
//         for (int i = 0; i < arr.length; i++) {
             int[] arr = new int[10];
             
 //           for (int i = 0; i < arr.length; i++) {
 //           arr[i] = (int)(Math.random() * 10);
      //  }
        
		int low = 0;
		int high = arr.length - 1;
// 
//		quickSort(x, low, high);
//		System.out.println(Arrays.toString(x));
//	}
 
	public static void quickSort() {

            int[] arr = new int[50000];
            
            int low = 0;
            int high = arr.length - 1;
            
            for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 50000;
        }
        
                 long startTime = System.currentTimeMillis();
		if (arr == null || arr.length == 0)
			return;
 
		if (low >= high)
			return;
 
		// pick the pivot
		int middle = low + (high - low) / 2;
		int pivot = arr[middle];
 
		// make left < pivot and right > pivot
		int i = low, j = high;
		while (i <= j) {
			while (arr[i] < pivot) {
				i++;
			}
 
			while (arr[j] > pivot) {
				j--;
			}
 
			if (i <= j) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i++;
				j--;
			}
		}
 
		// recursively sort two sub parts
		if (low < j)
                        quickSort();
		//	quickSort(arr, low, j);
 
		if (high > i)
                        quickSort();
		//	quickSort(arr, i, high);
                         
                         long endTime = System.currentTimeMillis();
     long executionTime = endTime - startTime;
      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of 50000 method
        
        	public static void quickSort100000() {

            int[] arr = new int[100000];
            
            int low = 0;
            int high = arr.length - 1;
            
            for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 100000;
        }
        
                 long startTime = System.currentTimeMillis();
		if (arr == null || arr.length == 0)
			return;
 
		if (low >= high)
			return;
 
		// pick the pivot
		int middle = low + (high - low) / 2;
		int pivot = arr[middle];
 
		// make left < pivot and right > pivot
		int i = low, j = high;
		while (i <= j) {
			while (arr[i] < pivot) {
				i++;
			}
 
			while (arr[j] > pivot) {
				j--;
			}
 
			if (i <= j) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i++;
				j--;
			}
		}
 
		// recursively sort two sub parts
		if (low < j)
                        quickSort();
		//	quickSort(arr, low, j);
 
		if (high > i)
                        quickSort();
		//	quickSort(arr, i, high);
                         
                         long endTime = System.currentTimeMillis();
     long executionTime = endTime - startTime;
      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of 100000 method
                
       	public static void quickSort150000() {

            int[] arr = new int[150000];
            
            int low = 0;
            int high = arr.length - 1;
            
            for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 150000;
        }
        
                 long startTime = System.currentTimeMillis();
		if (arr == null || arr.length == 0)
			return;
 
		if (low >= high)
			return;
 
		// pick the pivot
		int middle = low + (high - low) / 2;
		int pivot = arr[middle];
 
		// make left < pivot and right > pivot
		int i = low, j = high;
		while (i <= j) {
			while (arr[i] < pivot) {
				i++;
			}
 
			while (arr[j] > pivot) {
				j--;
			}
 
			if (i <= j) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i++;
				j--;
			}
		}
 
		// recursively sort two sub parts
		if (low < j)
                        quickSort();
		//	quickSort(arr, low, j);
 
		if (high > i)
                        quickSort();
		//	quickSort(arr, i, high);
                         
                         long endTime = System.currentTimeMillis();
     long executionTime = endTime - startTime;
      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of 150000 method
        
        	public static void quickSort200000() {

            int[] arr = new int[200000];
            
            int low = 0;
            int high = arr.length - 1;
            
            for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 200000;
        }
        
                 long startTime = System.currentTimeMillis();
		if (arr == null || arr.length == 0)
			return;
 
		if (low >= high)
			return;
 
		// pick the pivot
		int middle = low + (high - low) / 2;
		int pivot = arr[middle];
 
		// make left < pivot and right > pivot
		int i = low, j = high;
		while (i <= j) {
			while (arr[i] < pivot) {
				i++;
			}
 
			while (arr[j] > pivot) {
				j--;
			}
 
			if (i <= j) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i++;
				j--;
			}
		}
 
		// recursively sort two sub parts
		if (low < j)
                        quickSort();
		//	quickSort(arr, low, j);
 
		if (high > i)
                        quickSort();
		//	quickSort(arr, i, high);
                         
                         long endTime = System.currentTimeMillis();
     long executionTime = endTime - startTime;
      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of 200000 method
                
        	public static void quickSort250000() {

            int[] arr = new int[250000];
            
            int low = 0;
            int high = arr.length - 1;
            
            for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 250000;
        }
        
                 long startTime = System.currentTimeMillis();
		if (arr == null || arr.length == 0)
			return;
 
		if (low >= high)
			return;
 
		// pick the pivot
		int middle = low + (high - low) / 2;
		int pivot = arr[middle];
 
		// make left < pivot and right > pivot
		int i = low, j = high;
		while (i <= j) {
			while (arr[i] < pivot) {
				i++;
			}
 
			while (arr[j] > pivot) {
				j--;
			}
 
			if (i <= j) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i++;
				j--;
			}
		}
 
		// recursively sort two sub parts
		if (low < j)
                        quickSort();
		//	quickSort(arr, low, j);
 
		if (high > i)
                        quickSort();
		//	quickSort(arr, i, high);
                         
                         long endTime = System.currentTimeMillis();
     long executionTime = endTime - startTime;
      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of 250000 method
                
        	public static void quickSort300000() {

            int[] arr = new int[300000];
            
            int low = 0;
            int high = arr.length - 1;
            
            for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)Math.random() * 300000;
        }
        
                 long startTime = System.currentTimeMillis();
		if (arr == null || arr.length == 0)
			return;
 
		if (low >= high)
			return;
 
		// pick the pivot
		int middle = low + (high - low) / 2;
		int pivot = arr[middle];
 
		// make left < pivot and right > pivot
		int i = low, j = high;
		while (i <= j) {
			while (arr[i] < pivot) {
				i++;
			}
 
			while (arr[j] > pivot) {
				j--;
			}
 
			if (i <= j) {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i++;
				j--;
			}
		}
 
		// recursively sort two sub parts
		if (low < j)
                        quickSort();
		//	quickSort(arr, low, j);
 
		if (high > i)
                        quickSort();
		//	quickSort(arr, i, high);
                         
                         long endTime = System.currentTimeMillis();
     long executionTime = endTime - startTime;
      System.out.print("   " + (endTime - startTime) + "     ");
	} // end of 300000 method
} // end of class   

