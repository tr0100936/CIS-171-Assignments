package radixsortassignment;
// This program was modified from a program at
// http://www.sanfoundry.com/java-program-implement-radix-sort/
// as well as snippets of code from the textbook
import java.util.Scanner;

public class RadixSortAssignment {

    public static void main(String[] args) {
                Scanner scan = new Scanner( System.in );
        System.out.println("Radix Sort Test\n");
        int n, i;

         // Create an object
        RadixSortClass bike1 = new RadixSortClass();
        /** Accept number of elements **/
        //System.out.println("Enter number of integer elements");
        //n = scan.nextInt();
        /** Create integer array on n elements **/
        int[] arr = new int[1000];
        for (i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * 1000000);
        }
        /** Accept elements **/
        //System.out.println("\nEnter "+ n +" integer elements");
        //for (i = 0; i < n; i++)
         //   arr[i] = scan.nextInt();
        /** Call method sort **/
        bike1.sort(arr);
        // sort(arr);
        /** Print sorted Array **/
        System.out.println("\nElements after sorting ");
        for (i = 0; i < arr.length; i++)
           System.out.print(arr[i]+" ");
        System.out.println();
    }
}

    
    

